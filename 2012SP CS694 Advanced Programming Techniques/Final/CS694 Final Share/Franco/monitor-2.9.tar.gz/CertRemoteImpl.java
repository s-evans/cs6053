import java.rmi.*;
import java.rmi.server.*;

public class CertRemoteImpl extends UnicastRemoteObject
  implements CertRemote
{
      PlayerDB pDB;
      PlayerCertificate signer;

      CertRemoteImpl(PlayerDB d, PlayerCertificate s) 
          throws RemoteException {
          pDB = d;
          signer = s;
      };

      public PlayerCertificate getCert(String playerName) 
          throws RemoteException
      {
          if(signer != null && playerName.toUpperCase().equals("MONITOR"))
              return signer;
          return pDB.lookup(playerName).getCertIdentity();
      }
}
