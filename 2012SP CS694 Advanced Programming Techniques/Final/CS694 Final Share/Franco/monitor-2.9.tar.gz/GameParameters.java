// GameParameters.java                                           -*- Java -*-
//   All the constants for Game Parameters
//
// COPYRIGHT (C) 1998, Bradley M. Kuhn
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//
// Written   :   Bradley M. Kuhn         University of Cincinnati
//   By          
//
// Written   :   John Franco
//   For         Special Topics: Java Programming
//               15-625-595-001, Fall 1998
// RCS       :
//
// $Source: /home/cokane/src/Monitor-2.2-cokane/RCS/GameParameters.java,v $
// $Revision: 1.1 $
// $Date: 2004/01/22 04:50:56 $
//
// $Log: GameParameters.java,v $
// Revision 1.1  2004/01/22 04:50:56  cokane
// Initial revision
//
// Revision 0.9  1998/12/15 05:56:01  bkuhn
//   -- put files under the GPL
//
// Revision 0.8  1998/12/08 23:34:22  bkuhn
//   -- minor fixes
//
// Revision 0.6  1998/12/02 04:16:52  bkuhn
//    # increased version number
//    -- added INIMUM_PLAYERS_THAT_MUST_HOLD_EACH_RESOURCE
//
// Revision 0.5  1998/11/30 11:16:18  bkuhn
//   # changed to version 1.4
//   -- added GAME_DIRECTORY string
//   -- Added PLAYER_DATABASE_IS_STATIC variable
//   -- added PLAYER_DB_SERIALIZE_TIME
//   -- REMOVED STATISTICS_FILE, don't need it since I serialize
//      PlayerDB and all sub-objects into PLAYER_DB_FILE
//   -- added DH_KEY_FILE
//
// Revision 0.4  1998/11/29 23:11:58  bkuhn
//    # increased version number
//   -- added Cracking parameters
//
// Revision 0.3  1998/11/29 12:07:41  bkuhn
//   # changed version to 1.2
//   -- changed TRADE_CONFIRM_CONNECTION to TRANSACTION_CONFIRM_CONNECTION
//   -- added WAR_TRUCE_WINNER
//   -- added MONITOR_MARKUP_PERCENT and STATISTICS_FILE
//
// Revision 0.2  1998/11/25 09:30:28  bkuhn
//   # incremented VERSION number
//   -- added SECONDS_BETWEEN_RANDOM_PLAYER
//   -- added WAR_RUNNER times
//   -- added all the other WAR related variables
//   -- added PLAYER_HOST_PORT_COMPUTER_COST and MONITOR_IDENTITY
//
// Revision 0.1  1998/11/18 07:41:51  bkuhn
//   # initial version
//

/*****************************************************************************/
class GameParameters
{
      static final String rcsid = "$Revision: 1.1 $";


      /**********************************************************************/
      /* MONITOR  -- these are values used by the Monitor for serving  */

      // MONITOR_VERSION
      //   The version of the Monitor
      static final String MONITOR_VERSION = "2.9";

      public static String GAME_DIRECTORY = "";

      // MONITOR_SERVER_PORT 
      //  The port the monitor listens on
      public static int MONITOR_SERVER_PORT = 7777;

      // PLAYER_DATABASE_IS_STATIC
      //  Variable that is true iff. one cannot add to the Player Database

      public static boolean PLAYER_DATABASE_IS_STATIC = false;

      // MONITOR_MAX_CONNECTIONS
      //   Maximum number of connections the monitor permits before it starts
      //   refusing new connections
      public static final int MONITOR_MAX_CONNECTIONS = 100;

      /**********************************************************************/
      /* TIMEOUTS  --- these are values for timeouts on various connections */

      // ALIVE_CONNECTION_TIMEOUT
      // The amount of time (in seconds) to wait when Monitor makes a
      //  conneciton to check to see if someone is alive
      public static final double ALIVE_CONNECTION_TIMEOUT = 25.0;

      // TRANSACTION_CONFIRM_CONNECTION_TIMEOUT
      // The amount of time (in seconds) to wait when Monitor makes a
      //  conneciton to confirm a trade
      public static final double TRANSACTION_CONFIRM_CONNECTION_TIMEOUT = 45.0;

      // HOST_PORT_LOOKUP_TIMEOUT
      // The amount of time (in seconds) to wait while trying to verify
      //  that someone is on a particular host and port given by the HOST_PORT
      public static final double HOST_PORT_LOOKUP_TIMEOUT = 20.0;
      
      // INCOMING_CONNECTION_TIMEOUT
      // The amount of time (in seconds) to allow a Player to send commands
      //  on an incoming connection before kicking them off
      public static final double INCOMING_CONNECTION_TIMEOUT = 3 * 60.0;

      // MAX_COMMAND_RETRY_ON_REQUIRE and MAX_COMMAND_RETRY
      //   The number of times to allow a Player to retry a given command
      //     before forcing them to disconnect
      public static final int    MAX_COMMAND_RETRY            = 10;
      public static final int    MAX_COMMAND_RETRY_ON_REQUIRE =
                                                    MAX_COMMAND_RETRY / 2;

      // SECONDS_ALIVE_FOR_RESOURCES
      //  This is the number of seconds that a palyer must be alive
      //  to receive resources
      //  note that this should be less than or equal to the 
      //   AWARD_RESOURCES_TIME below.  Otherwise, the Players will
      //   never get any resources, because the AwardResources class
      //   resets the Player's seconds alive
      static final double SECONDS_ALIVE_FOR_RESOURCES = 10.0 * 60.0;

      // SECONDS_BETWEEN_RANDOM_PLAYER
      //  This is the number of seconds that a player must wait to 
      //  receive a random player's information
      static final double SECONDS_BETWEEN_RANDOM_PLAYER = 60.0 * 60.0 * 3.0;

      public static final int MAX_CONNECTIONS_PER_PERIOD = 120;
      /**********************************************************************/
      /* Recurring event timers         */

      public static final double CHECK_FOR_LIVING_MINIMUM_TIME = 5.0 * 60.0;
      public static final double CHECK_FOR_LIVING_MAXIMUM_TIME = 30.0 * 60.0;

      public static final double WAR_RUNNER_MINIMUM_TIME = 5.0 * 60.0;
      public static final double WAR_RUNNER_MAXIMUM_TIME = 10.0 * 60.0;

      public static final double AWARD_RESOURCES_TIME = 15.0 * 60.0;

      public static final double PLAYER_DB_SERIALIZE_TIME = 3.0 * 60.0;
      /**********************************************************************/
      /* Cracking         */
      // CRACK_PASSWORD_FACTOR
      //   The Factor to use to determine if a password is cracked

      public static final double CRACK_PASSWORD_FACTOR = 100.0;

      // CRACK_PLAYER_STATUS_FACTOR
      //   The Factor to use to determine if a Player_status is cracked

      public static final double CRACK_PLAYER_STATUS_FACTOR = 50.0;

      /**********************************************************************/
      /* War         */

      // BAD_WAR_PENALTY
      //   Percent penalty on a Player who declares war on wrong place 
      static final double BAD_WAR_PENALTY = .1;

      // NO_WAR_WINNER
      //   String to use when there is no winner yet to a war
      static final String NO_WAR_WINNER = "NONE";

      // WAR_TRUCE_WINNER
      //   String to use when there is a truce in a war
      static final String WAR_TRUCE_WINNER = "TRUCE";

      // PILLAGE_PERCENT_MIN
      //   Minimum percentage to allow of pillage after a war
      static final double PILLAGE_PERCENT_MIN = .75;

      // PILLAGE_PERCENT_MAX
      //   Maximum percentage to allow of pillage after a war
      static final double PILLAGE_PERCENT_MAX = .95;

      // WINNER_BATTLE_PERCENT_LOST_MIN
      //   minimum percentage of resource that a winner of a battle will lose

      static final double WINNER_BATTLE_PERCENT_LOST_MIN = 0.0;

      // WINNER_BATTLE_PERCENT_LOST_MAX
      //   maximum percentage of resource that a winner of a battle will lose
      static final double WINNER_BATTLE_PERCENT_LOST_MAX = 0.15;

      // LOSER_BATTLE_PERCENT_LOST_MIN
      //   minimum percentage of resource that a loser in a battle will lose

      static final double LOSER_BATTLE_PERCENT_LOST_MIN = 0.25;

      // LOSER_BATTLE_PERCENT_LOST_MAX
      //   maximum percentage of resource that a loser in a battle will lose

      static final double LOSER_BATTLE_PERCENT_LOST_MAX = 0.60;

      /**********************************************************************/
      /* Misc         */
      // ALLOTMENT_AMOUNT_TO_GIVE
      // This is the amount of items to give at each allotment time
      public static final int ALLOTMENT_AMOUNT_TO_GIVE = 140;

      // MONITOR_MARKUP_PERCENT
      // This is the amount that the monitor marks up on trades with it
      public static final double MONITOR_MARKUP_PERCENT = .10;

      // PASSWORD_LENGTH 
      //  The length, in bits, of the passwords that are chosen by the system
      static final int PASSWORD_LENGTH = 98;


      // CHANGE_AMOUNT_FOR_SYNTHESIZE
      //   Amount to change a resource by to synthesize another resource
      static final long CHANGE_AMOUNT_FOR_SYNTESIZE = 2;

      // PLAYER_HOST_PORT_COMPUTER_COST
      //   Cost of Computer resources needed to run the PLAYER_HOST_PORT
      //   command
      static final int PLAYER_HOST_PORT_COMPUTER_COST = 1;

      // MONITOR_IDENTITY
      //   The Identity to use for Monitor
      static final String MONITOR_IDENTITY = "MONITOR";

      // PLAYER_DB_FILE
      //   File where statistics are stored
      static final String PLAYER_DB_FILE = "players.db";

      // MINIMUM_PLAYERS_THAT_MUST_HOLD_EACH_RESOURCE
      // The miminum players that must hold each resource...to make
      //  sure that there is enough of each resource in the game.

      public static int MINIMUM_PLAYERS_THAT_MUST_HOLD_EACH_RESOURCE = 5;

      /**********************************************************************/
      /* Encrytption         */

     /* Certification Authority Key Signing, Verification */
	  /** Server "Signer's" Certificate. **/
	  static final String MONITOR_CERT = "MonitorCert";

	  /** Server's Private RSA Key, for signing. **/
	  static final String MONITOR_RSAPRIV = "MonitorKey";

	  /** Contact printed in unexpected error context **/
	  static final String SERVICE_CONTACT = "project@helios.ececs.uc.edu";
}
/*
  Local Variables:
  tab-width: 4
  indent-tabs-mode: nil
  eval: (c-set-style "ellemtel")
  End:
*/

