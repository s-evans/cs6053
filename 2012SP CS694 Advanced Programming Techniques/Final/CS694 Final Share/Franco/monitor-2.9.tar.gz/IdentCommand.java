// Command.java                                                 -*- Java -*-
//   Commands avaiable to the monitor
//
// COPYRIGHT (C) 1998, Bradley M. Kuhn
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//
// Written   :   Bradley M. Kuhn         University of Cincinnati
//   By          
//
// Written   :   John Franco
//   For         Special Topics: Java Programming
//               15-625-595-001, Fall 1998
// RCS       :
//
// $Source: /home/cokane/src/Monitor-2.9/RCS/IdentCommand.java,v $
// $Revision: 1.2 $
// $Date: 2004/03/13 00:29:14 $
//
// $Log: IdentCommand.java,v $
// Revision 1.2  2004/03/13 00:29:14  cokane
// Fix a prevalent NumberFormatException
//
// Revision 1.1  2004/01/22 04:50:56  cokane
// Initial revision
//
// Revision 0.8  1998/12/15 05:56:01  bkuhn
//   -- put files under the GPL
//
// Revision 0.7  1998/11/30 06:34:34  bkuhn
//   -- added support for an exchangeKey optional parameter to do
//      DiffieHellman and subsequent encryption
//
// Revision 0.6  1998/11/29 12:01:51  bkuhn
//   # added a test for WAR_TRUCE_WINNER as well as others
//
// Revision 0.5  1998/11/25 04:19:46  bkuhn
//   -- made sure that certain identities are never given to players
//      because they have special meaning (i.e., MONITOR and NONE)
//
// Revision 0.4  1998/11/13 08:35:13  bkuhn
//   # cosmetic changes
//
// Revision 0.3  1998/11/09 04:04:46  bkuhn
//   # cosmetic changes
//
// Revision 0.2  1998/11/03 06:15:53  bkuhn
//    # cosmetic changes
//

import java.io.*;
import java.math.BigInteger;

/**********************************************************************/
class IdentCommand  extends Command
{
      public final static String COMMAND_STRING = "IDENT";

      String identity;
      String exchangeKey;

      /**********************************************************************/
      String getCommandMessage()
      {
         return new String(COMMAND_STRING);
      }
      /**********************************************************************/
      IdentCommand()
      {
      }
      /**********************************************************************/
      IdentCommand(String args[])  throws CommandException
      {
         initialize(args);
      }
      /**********************************************************************/
      void initialize(String args[]) throws CommandException
      {
         super.initialize(args);

         exchangeKey = null;

         try
         {
            identity = arguments[1];  // Actually look this person up!
         }
         catch (ArrayIndexOutOfBoundsException abe)
         {
            throw new CommandException("command, " + arguments[0] + 
            ", requires one or two arguments, <IDENTITY> (<RSA_XCHG_KEY_ENC>)");
         }

         if (arguments.length >= 3)
            exchangeKey = arguments[2];

         if (identity.equalsIgnoreCase(GameParameters.MONITOR_IDENTITY) || 
             identity.equalsIgnoreCase(GameParameters.NO_WAR_WINNER) ||
             identity.equalsIgnoreCase(GameParameters.WAR_TRUCE_WINNER) )
            throw new CommandException(
               "Invalid IDENTITY given, please give another.");
      }
      /**********************************************************************/
      // verify() checks to see if this command is permitted
      public boolean verify(MonitorSession session)
      {
          session.initEngine(identity);
          try {
              if (exchangeKey == null ||
                      session.setExchangeKey(new BigInteger(exchangeKey, 0x20)))
                  return true;
              else
              {
                  session.sendError("Invalid encoded RSA key");
                  return false;
              }
          } catch(NumberFormatException nfx) {
              session.sendError("Invalid key portion (must be base32)");
              return false;
          }
      }
      /**********************************************************************/
      // execute() actually carries out the behavior for the command
      public void execute(MonitorSession session) 
      {
         if (exchangeKey != null)
         {
            session.sendResult(getCommandMessage() + " " +
                               session.getExchangeKey());
            session.enableCipherMode();
         }
      }
      /**********************************************************************/
      public void echo(MonitorSession session) {
         session.println(Directive.COMMENT_DIRECTIVE +
                     "Your identity appears to be: " + identity);
      }
      /**********************************************************************/
      String getIdent() {
         return new String(identity);
      }
}
/*
  Local Variables:
  tab-width: 4
  indent-tabs-mode: nil
  eval: (c-set-style "ellemtel")
  End:
*/
