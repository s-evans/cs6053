import java.lang.*;
import java.io.*;
import java.security.*;
import java.math.*;

public class MakeRSA {
    public static void main(String args[]) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            RSA secretKey = new RSA();
            md.update(secretKey.publicKey().getExponent().toByteArray());
            md.update(secretKey.publicKey().getModulus().toByteArray());

            BigInteger h = new BigInteger(1, md.digest());

            PlayerCertificate monCert = 
                new PlayerCertificate(secretKey.publicKey(), "MONITOR", h);

            ObjectOutputStream oos = new ObjectOutputStream(
                    new FileOutputStream("MonitorCert"));
            oos.writeObject(monCert);
            oos.close();

            oos = new ObjectOutputStream(
                    new FileOutputStream("MonitorKey"));
            oos.writeObject(secretKey);
            oos.close();
        } catch(NoSuchAlgorithmException nsax) {
            System.out.println("Can't find sha-1");
        } catch(FileNotFoundException fnfx) {
            System.out.println("File not found");
        } catch(IOException iox) {
            System.out.println("There was an I/O Exception");
        }
    }
}
