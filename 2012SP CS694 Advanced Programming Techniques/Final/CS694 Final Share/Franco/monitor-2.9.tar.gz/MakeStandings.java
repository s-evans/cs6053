import java.io.*;
import java.util.*;

public class MakeStandings {
   PlayerDB playerDB;
   Economy economy;
   double rupyulars, weapons, computers, vehicles, copper, oil, steel,
   plastic, glass, rubber;

   MakeStandings(String filename) {
      playerDB = null;
      try {
         FileInputStream fis = new FileInputStream(filename);
         ObjectInputStream ois = new ObjectInputStream(fis);
         playerDB = (PlayerDB) ois.readObject();
         ois.close();
         economy = playerDB.getEconomy();
         rupyulars = economy.getResourceValueByName("rupyulars").getMarketValue();
         weapons = economy.getResourceValueByName("weapons").getMarketValue();
         computers = economy.getResourceValueByName("computers").getMarketValue();
         vehicles = economy.getResourceValueByName("vehicles").getMarketValue();
         copper = economy.getResourceValueByName("copper").getMarketValue();
         oil = economy.getResourceValueByName("oil").getMarketValue();
         steel = economy.getResourceValueByName("steel").getMarketValue();
         plastic = economy.getResourceValueByName("plastic").getMarketValue();
         glass = economy.getResourceValueByName("glass").getMarketValue();
         rubber = economy.getResourceValueByName("rubber").getMarketValue();
      }
      catch (Exception e) {
         System.out.println("CANNOT READ DB: " + e);
      }
   }
	
   void processPlayers() {
      Player p[] = new Player[500];
      double w[] = new double[500];
      FileWriter os = null;
      
      try {
         FileOutputStream fos = new FileOutputStream("standings8180.html");
         os = new FileWriter(fos.getFD());
         
         Date date = new Date();
         String ds = date.toString();
         
         // Print the file header
         os.write(
          "<html>\n"+
          "<head>\n"+
          "<META http-equiv=\"Refresh\" CONTENT=\"180;url=http://gauss.ececs.uc.edu/standings8180.html\">\n"+
          "<title>Standings of Final Tournament</title>\n"+
          "</head>\n"+
          "<body bgcolor=\"#ffffdf\">\n"+
          "<center>\n"+
          "<table cellspacing=10>\n"+
          "<tr>\n"+
          "<td align=\"CENTER\" width=300><font size=-1>20-ECES-694-001</font></td>\n"+
          "<th><b><font size=+2 color=\"#BB0000\">Java Project</font></b></th>\n"+
          "<td align=\"CENTER\" width=300><font size=-1>Spring 2005</font></td>\n"+
          "</tr>\n"+
          "</table><p>\n"+
          "<font size=+2 color=\"#0000BB\"><b><nobr>I-Wars Standings: Final Tournament</nobr></b></font><p>\n"+
          "<font size=-1 color=\"#cc0000\">"+ds+"</font><p>\n"+
          "<font size=+2 color=\"#00bb00\"><b>Sorry, I had to restart - malicious student penalty</b></nobr></font></h1><p>\n"+
          "</center>\n"+
          "<font color=\"#0000bb\"><b>Conversions (by the hundreds):</b></font><br>\n"+
          "<table>\n"+
          "<tr><td width=100>Rupyulars:</td>\n"+
          "    <td width=150>"+(int)(rupyulars*100)+"</td>\n"+
          "    <td width=100>Steel:</td>\n"+
          "    <td width=150>"+(int)(steel*100)+"</td></tr>\n"+
          "<tr><td>Computers:</td><td>"+(int)(computers*100)+"</td>\n"+
          "    <td>Copper:</td><td>"+(int)(copper*100)+"</td></tr>\n"+
          "<tr><td>Vehicles:</td><td>"+(int)(vehicles*100)+"</td>\n"+
          "    <td>Glass:</td><td>"+(int)(glass*100)+"</td></tr>\n"+
          "<tr><td>Weapons:</td><td>"+(int)(weapons*100)+"</td>\n"+
          "    <td>Plastic:</td><td>"+(int)(plastic*100)+"</td></tr>\n"+
          "<tr><td>Rubber:</td><td>"+(int)(rubber*100)+"</td>\n"+
          "    <td>Oil:</td><td>"+(int)(oil*100)+"</td></tr>\n"+
          "</table>\n"+
          "<p>\n"+
          "<font color=\"#0000bb\"><b>Standings:</b><br></font>\n"+
          "<table>\n"+
          "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><b><font color=\"#0000bb\"><u>Wars</u></font></b></td><td>&nbsp;</td></tr>\n"+
          "<th><font color=\"#0000bb\"><u>Player</u></font></th><th><font color=\"#0000bb\"><u>Rank</u></font></th><th><font color=\"#0000bb\"><u>Wealth</u></font></th><th>&nbsp;&nbsp;&nbsp;</th><th><font color=\"#0000bb\"><u>Won</u></font></th><th><font color=\"#0000bb\"><u>Lost</u></font></th><th><font color=\"#0000bb\"><u>Declared</u></font></th>\n");
         
         int index = 0;
         for (Enumeration e = playerDB.getPlayers() ; e.hasMoreElements() ; ) {
            Player curPlayer = (Player) e.nextElement();
            Wealth wealth = curPlayer.getWealth();
            long rup = wealth.getHolding("rupyulars");
            long wea = wealth.getHolding("weapons");
            long com = wealth.getHolding("computers");
            long veh = wealth.getHolding("vehicles");
            long cop = wealth.getHolding("copper");
            long oi  = wealth.getHolding("oil");
            long ste = wealth.getHolding("steel");
            long pla = wealth.getHolding("plastic");
            long gla = wealth.getHolding("glass");
            long rub = wealth.getHolding("rubber");
            
            double amount = rup*rupyulars + wea*weapons + com*computers +
               veh*vehicles + cop*copper + oil*oi + ste*steel +
               pla*plastic + gla*glass + rub*rubber;
            
            int i = index;
            for ( ; i > 0 && amount > w[i-1] ; i--) {
               w[i] = w[i-1];
               p[i] = p[i-1];
            }
            w[i] = amount;
            p[i] = curPlayer;
            index++;
         }
				
         for (int i=0 ; i < index ; i++) {
            SillyPlayerWrapper sp = new SillyPlayerWrapper("Foo",playerDB.getEconomy());
            
            int leng = p[i].getIdentity().length();
            if (leng > 20) leng = 20;
            String player_name = p[i].getIdentity().substring(0,leng);
            if (p[i].getIdentity().equals("PPL")) player_name += "*";
            os.write(
              "<tr><td>"+player_name+"</td>"+
              "<td align=\"CENTER\">"+(i+1)+"</td>"+
              "<td align=\"CENTER\">"+(long)w[i]+"</td><td>  </td>"+
              "<td align=\"CENTER\">"+sp.getWarsWon(p[i])+"</td>"+
              "<td align=\"CENTER\">"+sp.getWarsLost(p[i])+"</td>"+
              "<td align=\"CENTER\">"+sp.getWarsDeclared(p[i])+"</td></tr>\n");
         }
         os.write("</table><p>\n");
         os.close();
      }
      catch (Exception e) { System.out.println(e); }
   }
   
   public static void main(String argv[]) {
      MakeStandings ms = new MakeStandings(argv[0]);
      ms.processPlayers();
   }
}
/*
  Local Variables:
  tab-width: 4
  indent-tabs-mode: nil
  eval: (c-set-style "ellemtel")
  End:
*/
