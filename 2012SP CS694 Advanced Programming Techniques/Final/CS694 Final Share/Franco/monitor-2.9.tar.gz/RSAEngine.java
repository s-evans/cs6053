/****** RSAEngine - Engine to handle the RSA key exchange and
 * calculation
 ****************************************************************/

/* RCS Info:
   $Id: RSAEngine.java,v 1.1 2004/01/22 04:50:56 cokane Exp cokane $
   $Revision: 1.1 $
   $Date: 2004/01/22 04:50:56 $

   $Log: RSAEngine.java,v $
   Revision 1.1  2004/01/22 04:50:56  cokane
   Initial revision

*/

import java.io.*;
import java.math.BigInteger;
import java.security.*;

class RSAEngine {
    /** The entropy generator, define as static so the same one
     * is available for all instances of this class. **/
    static SecureRandom sr = null;

    final int keySize = 512;
    final int RADIX = 32;

    private BigInteger myHalf;
    private BigInteger yourHalf;
    private BigInteger sharedSecret;
    RSA myRSAKey;
    PubRSA yourRSAPublicKey;

    RSAEngine(RSA serverSecretKey, PubRSA clientPublicKey) {
        if(sr == null)
            sr = new SecureRandom();
        myRSAKey = serverSecretKey;
        yourRSAPublicKey = clientPublicKey;
        while((myHalf = new BigInteger(keySize/2, sr)).compareTo(
                    yourRSAPublicKey.getModulus()) >= 0);
    }

    BigInteger getSharedKey() {
        if(yourHalf == null)
            return null;

        byte k[], localBytes[], remoteBytes[];
        ByteArrayOutputStream bos = 
            new ByteArrayOutputStream(keySize/8);

        localBytes = myHalf.toByteArray();
        remoteBytes = yourHalf.toByteArray();
/*      //Used for debugging key exchange
        System.out.println("MY: " + myHalf.toString(32));
        System.out.println("YU: " + yourHalf.toString(32));
        */
        for(int i = 0; i < keySize/16; i++) {
            bos.write(localBytes[i]);
            bos.write(remoteBytes[i]);
        }

        return (sharedSecret = new BigInteger(1, bos.toByteArray()));
    }

    String getMyHalfEncrypted() {
        /*
        // For debugging key exchange
        System.out.println("YourKey: " + 
                yourRSAPublicKey.getModulus().toString(32));
                */
        return yourRSAPublicKey.encrypt(myHalf).toString(RADIX);
    }

    void setYourHalf(String clientHalfString) {
        yourHalf = myRSAKey.decryptNum(
                new BigInteger(clientHalfString, RADIX));
    }
}
