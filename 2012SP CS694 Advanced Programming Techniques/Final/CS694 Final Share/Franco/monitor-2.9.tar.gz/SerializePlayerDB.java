// SerializePlayerDB.java                                         -*- Java -*-
//    Serialize the Player database periodically
//
// COPYRIGHT (C) 1998, Bradley M. Kuhn
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//
// Written   :   Bradley M. Kuhn         University of Cincinnati
//   By          
//
// Written   :   John Franco
//   For         Special Topics: Java Programming
//               15-625-595-001, Fall 1998
// RCS       :
//
// $Source: /home/cokane/src/Monitor-2.2-cokane/RCS/SerializePlayerDB.java,v $
// $Revision: 1.1 $
// $Date: 2004/01/22 04:50:56 $
//
// $Log: SerializePlayerDB.java,v $
// Revision 1.1  2004/01/22 04:50:56  cokane
// Initial revision
//
// Revision 0.3  1998/12/15 05:56:01  bkuhn
//   -- put files under the GPL
//
// Revision 0.2  1998/12/02 03:03:47  bkuhn
//    -- increased this thread's priority
//
// Revision 0.1  1998/11/30 11:22:29  bkuhn
//   # initial version
//


import java.util.Enumeration;
import java.io.*;
/*****************************************************************************/
class SerializePlayerDB extends Thread implements RecurredEvent
{
      PlayerDB playerDB;
      static final String rcsid = "$Revision: 1.1 $";

      SerializePlayerDB()
      {
      }
      /**********************************************************************/
      public void initialize(Object o)
      {
         playerDB = (PlayerDB) o;
      }
      /**********************************************************************/
      public void run()
      {
         Player curPlayer;

         setPriority(MAX_PRIORITY - 1);

         System.out.println("SERIALIZE_PLAYER_DB: Beginning...");

         // First, if we have any players, update the economy
         for(Enumeration e = playerDB.getPlayers(); e.hasMoreElements() ; )
         {
            ((Player) e.nextElement()).getEconomy().updateStatistics();
            break;
         }

         try
         {
            FileOutputStream fos = new FileOutputStream(
               GameParameters.GAME_DIRECTORY + "/" + 
               GameParameters.PLAYER_DB_FILE);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject( (Object) playerDB);
            oos.close();
         }
         catch (Exception e)
         {
            System.out.println("SERIALIZE_PLAYER_DB: FATAL ERROR---" + e);
         }

         System.out.println("SERIALIZE_PLAYER_DB: Ending...");
      }
      /**********************************************************************/
}
/*
  Local Variables:
  tab-width: 4
  indent-tabs-mode: nil
  eval: (c-set-style "ellemtel")
  End:
*/
