// SynthesizeCommand.java                                         -*- Java -*-
//   Command to synthesize more complex resources
//
// COPYRIGHT (C) 1998, Bradley M. Kuhn
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//
// Written   :   Bradley M. Kuhn         University of Cincinnati
//   By          
//
// Written   :   John Franco
//   For         Special Topics: Java Programming
//               15-625-595-001, Fall 1998
// RCS       :
//
// $Source: /home/cokane/src/Monitor-2.2-cokane/RCS/SynthesizeCommand.java,v $
// $Revision: 1.1 $
// $Date: 2004/01/22 04:50:56 $
//
// $Log: SynthesizeCommand.java,v $
// Revision 1.1  2004/01/22 04:50:56  cokane
// Initial revision
//
// Revision 0.3  1998/12/15 05:56:01  bkuhn
//   -- put files under the GPL
//
// Revision 0.2  1998/11/30 03:18:25  bkuhn
// -- changed things to use new println() method in MonitorSession
//
// Revision 0.1  1998/11/18 03:35:17  bkuhn
//   # initial version
//

import java.io.*;

/*****************************************************************************/
class SynthesizeCommand extends Command
{
      public static final String COMMAND_STRING = "SYNTHESIZE";

      String resource;

      /**********************************************************************/
      void initialize(String args[]) throws CommandException
      {
         super.initialize(args);

         resource  = "";
         try
         {
            resource = arguments[1];
         }
         catch (ArrayIndexOutOfBoundsException abe)
         {
            throw new CommandException("command, " + arguments[0] + 
                            ", requires one argument, <RESOURCE>");
         } 
         resource = resource.toLowerCase();
      }
      /**********************************************************************/
      String getCommandMessage()
      {
         return new String(COMMAND_STRING);
      }
      /**********************************************************************/
      public void execute(MonitorSession session)
      {
         try
         {
           if (session.getPlayer().getWealth().synthesize(resource))
              session.sendResult(COMMAND_STRING + " " + resource + " " +
                                 "holdings increased by one.");
           else
              session.sendError("unable to synthesize this resource");
         }
         catch(UnknownResourceException ure)
         {
            session.sendError(ure.getMessage());
         }
         catch(InsufficientResourceException ure)
         {
            session.sendError(ure.getMessage());
         }
      }
      /**********************************************************************/
      public boolean verify(MonitorSession session)
      {
         try
         {
            if ( session.getPlayer() != null &&
                 session.getPlayer().getWealth() != null &&
                 session.getPlayer().getWealth().getHolding(resource) >= 0)
               return true;
            else 
               session.sendError("Player is not known");
         }
         catch(UnknownResourceException ure)
         {
            session.sendError(ure.getMessage());
         }
         return false;
      }
      /**********************************************************************/
      public void echo(MonitorSession session) {
         session.println(Directive.COMMENT_DIRECTIVE +
                     "Attempting to synthesize resource...");
      }
}
/*
  Local Variables:
  tab-width: 4
  indent-tabs-mode: nil
  eval: (c-set-style "ellemtel")
  End:
*/

