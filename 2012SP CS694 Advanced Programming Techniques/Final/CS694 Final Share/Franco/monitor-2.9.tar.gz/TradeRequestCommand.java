// TradeRequestCommand.java                                     -*- Java -*-
//   Command to request trades
//
// COPYRIGHT (C) 1998, Bradley M. Kuhn
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//
// Written   :   Bradley M. Kuhn         University of Cincinnati
//   By          
//
// Written   :   John Franco
//   For         Special Topics: Java Programming
//               15-625-595-001, Fall 1998
// RCS       :
//
// $Source: /home/cokane/src/Monitor-2.2-cokane/RCS/TradeRequestCommand.java,v $
// $Revision: 1.1 $
// $Date: 2004/01/22 04:50:56 $
//
// $Log: TradeRequestCommand.java,v $
// Revision 1.1  2004/01/22 04:50:56  cokane
// Initial revision
//
// Revision 0.5  1998/12/15 05:56:01  bkuhn
//   -- put files under the GPL
//
// Revision 0.4  1998/12/01 21:51:37  bkuhn
//    -- Fixed bug with trade
//
// Revision 0.3  1998/11/30 03:18:24  bkuhn
// -- changed things to use new println() method in MonitorSession
//
// Revision 0.2  1998/11/29 12:02:07  bkuhn
//    # changed some types from int to long
//   -- added code to handle trades with MONITOR
//   -- added check to see if Player was trying to trade with themselves
//   -- changed use of TradeConfirmConnection to TransactionConfirmConnection
//
// Revision 0.1  1998/11/18 07:32:04  bkuhn
//   # initial version
//

import java.util.*;
import java.io.*;
import java.net.*;
/*****************************************************************************/
class TradeRequestCommand extends Command {
      public static final String COMMAND_STRING = "TRADE_REQUEST";

      Player playerTo;
      String identityTo;
      String identityFrom;
      long amountFrom;
      long amountTo;
      String resourceFrom;
      String resourceTo;
      String tradeData;
      TransactionConfirmConnection tradeConnection;

      /**********************************************************************/
      // verify() checks to see if this command is permitted
      public Player getPlayerToTradeWith() {
         return playerTo;
      }
      /**********************************************************************/
      String getCommandMessage() {
         return new String(COMMAND_STRING);
      }
      /**********************************************************************/
      void initialize(String args[]) throws CommandException {
         super.initialize(args);

         String forString;

         try {
            identityFrom = arguments[1];
            resourceFrom = arguments[2];
            amountFrom   = Long.parseLong(arguments[3]);
            forString    = arguments[4];
            identityTo = arguments[5];
            resourceTo = arguments[6];
            amountTo   = Long.parseLong(arguments[7]);
            
            tradeData = "";
            for(int ii = 1; ii < 8; ii ++)
               tradeData = tradeData.concat(arguments[ii] + " ");
         }
         catch (ArrayIndexOutOfBoundsException abe) {
            throw new CommandException("command, " + arguments[0] + 
          ", requires seven arguments, <IDENTITY1> <RESOURCE1> <AMOUNT1> " +
                                  "for <IDENTITY2> <RESOURCE2> <AMOUNT2>");
         } 
         catch(NumberFormatException ne) {
            throw new CommandException("Amounts must be integers");
         }

         if (! forString.equalsIgnoreCase("for") )
            throw new CommandException(
               "ARG4 must be \"for\"");

         if (amountFrom < 0 || amountTo < 0)
            throw new CommandException(
               "Only positive amounts may be traded");

         if (amountFrom == 0 || amountTo == 0)
            throw new CommandException(
               "One of the traders must be giving something");

      }
      /**********************************************************************/
      public void execute(MonitorSession session) {
         Player thisPlayer = session.getPlayer();

         try {
            if (identityTo.equalsIgnoreCase(GameParameters.MONITOR_IDENTITY)) {
               // This is a MONITOR trade...see if we can do it
               if (thisPlayer.getEconomy().trade(thisPlayer,
                            resourceFrom, amountFrom, resourceTo, amountTo)) 
                  session.sendResult(COMMAND_STRING + " ACCEPTED");
               else
                  session.sendResult(COMMAND_STRING + " REJECTED");
            }
            else if (playerTo.getWealth().getHolding(resourceTo) < amountTo)
               // if they don't have enough, we never even ask them, we
               // just say the trade was rejected
               session.sendResult(COMMAND_STRING + " REJECTED");
            else {
               if (tradeConnection.getMessage().equalsIgnoreCase("ACCEPTED")) {
                  thisPlayer.getWealth().changeHolding(resourceFrom, 
                                                       0 - amountFrom);
                  playerTo.getWealth().changeHolding(resourceFrom, amountFrom);
                  
                  playerTo.getWealth().changeHolding(resourceTo, 0 - amountTo);
                  thisPlayer.getWealth().changeHolding(resourceTo, amountTo);
               }
               session.sendResult(COMMAND_STRING + " " +
                                  tradeConnection.getMessage());
            }
         }
         catch (UnknownResourceException ure)
         {
            session.sendError(
               "FATAL TRADE ERROR: post to java-project@ebb.org (" + 
               ure.getMessage() + ")");
         }
         catch (InsufficientResourceException ire)
         {
            session.sendError(
               "FATAL TRADE ERROR: post to java-project@ebb.org (" + 
               ire.getMessage() + ")");
         }
      }
      /**********************************************************************/
      public void echo(MonitorSession session) {
         session.println(Directive.COMMENT_DIRECTIVE + 
                     "Seeing if trade can be executed...");
      }
      /**********************************************************************/
      public boolean verify(MonitorSession session)
      {
         if (! identityFrom.equalsIgnoreCase(session.getPlayer().
                                             getIdentity())  )
         {
            session.sendError(session.getPlayer().getIdentity() +
                              " is not permitated to trade as " +
                              identityFrom);
            return false;
         }
         if (identityFrom.equalsIgnoreCase(identityTo))
         {
            session.sendError("trading with yourself is counter-productive");
            return false;
         }
            
         playerTo = session.getPlayerDB().lookup(identityTo);

         if (playerTo == null && (! identityTo.equalsIgnoreCase(
                                         GameParameters.MONITOR_IDENTITY) ) )
         {
            session.sendError("unable to find player with identity, "
                             + identityTo);
            return false;
         }
         try {
            if (session.getPlayer().getWealth().getHolding(resourceFrom)
                               < amountFrom)
            {
               session.sendError(identityFrom +
                                 " holds less than " + amountFrom +
                                 " units of " + resourceFrom);
               return false;
            }
            if (playerTo == null)
            {
               // Note: this is just a dummy check to see if we get an
               //       exception thrown on resource value
               if (session.getPlayer().getWealth().getHolding(resourceTo) >= 0)
                  return true;
            }
            else 
            {
               if (playerTo.getWealth().getHolding(resourceTo) < amountTo)
                  // just pretend and return true---check again in execute()
                  return true;
            }
         }
         catch (UnknownResourceException ure)
         {
            session.sendError(ure.getMessage());
            return false;
         }

         if ( identityTo.equalsIgnoreCase(
                                         GameParameters.MONITOR_IDENTITY) )
            return true;
         else
         {
            // A trade with a regular player, not the MONITOR

            tradeConnection = null;
            
            try
            {
               tradeConnection = 
                  new TransactionConfirmConnection(session.getPlayerDB(), 
                              playerTo, Directive.TRADE_DIRECTIVE + tradeData,
                                 TradeResponseCommand.COMMAND_STRING);
            }
            catch (MonitorSessionException mse)
            {
               session.sendError("unable to make connection to verify trade");
               return false;
            }
            tradeConnection.start();
            
            try { tradeConnection.join(); }
            catch(InterruptedException ie) { }

            return true;
         }
      }
      /**********************************************************************/
}
/*
  Local Variables:
  tab-width: 4
  indent-tabs-mode: nil
  eval: (c-set-style "ellemtel")
  End:
*/

