#include <stdlib.h>
#include <stdio.h>

int main (int argc, char **argv) {
	char *t, *p;
	char buf[1024];
	char word[1024];
	if (argc != 2) {
		printf("Usage: %s word\n", argv[0]);
		exit(0);
	}
	strcpy(word, argv[1]);
	
	while (1) {
		fgets(buf, 1024, stdin);
		t = buf;
      while (*t != '\n' && *t != 0) {
			for (p=t ; *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r' ; p++);
			if (!strncmp(t, word, strlen(word))) {
				system("./standings_record");
			}
         for (t=p ; *t == ' ' || *t == '\t' ; t++);
		}
	}
}
