public class DebugConfig {
    public static boolean[] DebugLevels = {
        true, //ALL
        true, //ACTIVE_CLIENT
        true, //SERVER
        true, //MESSAGE_PARSER
        true, //CONNECTION_HANDLER
        true  //PASSWORD CLIENT
    };
}
